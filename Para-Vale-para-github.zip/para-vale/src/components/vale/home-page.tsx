import { useEffect, useState } from "react";
import { Gate } from "./gate";
import { Letter } from "./letter";
import { Grain, Petals, ScrollProgress } from "./motion";

type Phase = "gate" | "leaving" | "letter";

export function HomePage() {
  const [phase, setPhase] = useState<Phase>("gate");

  useEffect(() => {
    const lock = phase !== "letter";
    document.body.style.overflow = lock ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [phase]);

  useEffect(() => {
    if (phase !== "leaving") return;
    const id = window.setTimeout(() => {
      setPhase("letter");
      window.scrollTo(0, 0);
    }, 720);
    return () => window.clearTimeout(id);
  }, [phase]);

  const open = () => {
    if (phase === "gate") setPhase("leaving");
  };

  const restart = () => {
    window.scrollTo(0, 0);
    setPhase("gate");
  };

  return (
    <main className="relative min-h-dvh bg-night text-fg">
      <Grain />
      <Petals />
      <ScrollProgress active={phase === "letter"} />

      {phase !== "letter" ? <Gate leaving={phase === "leaving"} onOpen={open} /> : null}

      {phase === "letter" ? (
        <div id="carta">
          <Letter onRestart={restart} />
        </div>
      ) : null}
    </main>
  );
}
