import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { cn } from "@/lib/utils";

const PETALS = [
  { left: 6, delay: 0, duration: 16, size: 11, drift: 36 },
  { left: 14, delay: 2.4, duration: 18, size: 8, drift: -28 },
  { left: 22, delay: 5.1, duration: 14, size: 13, drift: 22 },
  { left: 31, delay: 1.2, duration: 20, size: 9, drift: -40 },
  { left: 39, delay: 7.8, duration: 15, size: 12, drift: 18 },
  { left: 48, delay: 3.6, duration: 17, size: 7, drift: -22 },
  { left: 56, delay: 9.2, duration: 19, size: 10, drift: 44 },
  { left: 64, delay: 0.8, duration: 13, size: 14, drift: -16 },
  { left: 72, delay: 6.4, duration: 16, size: 8, drift: 30 },
  { left: 81, delay: 4.1, duration: 21, size: 11, drift: -34 },
  { left: 88, delay: 8.6, duration: 15, size: 9, drift: 12 },
  { left: 94, delay: 2.9, duration: 18, size: 12, drift: -24 },
] as const;

export function Grain() {
  return <div className="grain" aria-hidden="true" />;
}

export function Petals() {
  return (
    <div className="petal-layer" aria-hidden="true">
      {PETALS.map((p, i) => (
        <span
          key={i}
          className="petal"
          style={
            {
              left: `${p.left}%`,
              width: p.size,
              height: p.size * 1.35,
              animationDelay: `${p.delay}s`,
              animationDuration: `${p.duration}s`,
              "--drift": `${p.drift}px`,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}

export function ScrollProgress({ active }: { active: boolean }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!active) return;
    const onScroll = () => {
      const root = document.documentElement;
      const max = root.scrollHeight - root.clientHeight;
      setProgress(max > 0 ? root.scrollTop / max : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [active]);

  if (!active) return null;
  return (
    <div
      className="scroll-progress"
      style={{ "--progress": progress } as CSSProperties}
      aria-hidden="true"
    />
  );
}

export function Reveal({
  children,
  className,
  delay = 0,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "section" | "article" | "figure" | "p" | "h2" | "blockquote" | "li";
}) {
  const ref = useRef<HTMLElement | null>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      setShown(true);
      return;
    }
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setShown(true);
          io.disconnect();
        }
      },
      { threshold: 0.16, rootMargin: "0px 0px -8% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <Tag
      ref={ref as never}
      className={cn("reveal", shown && "is-in", className)}
      style={{ "--delay": `${delay}ms` } as CSSProperties}
    >
      {children}
    </Tag>
  );
}
