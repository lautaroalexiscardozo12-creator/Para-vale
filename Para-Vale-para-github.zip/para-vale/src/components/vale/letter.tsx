import { useEffect, useState, type KeyboardEvent, type MouseEvent } from "react";
import { ChevronDown, Flame, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { Reveal } from "./motion";

const NOTES = [
  {
    title: "Tu risa",
    body: "Cambia el clima de una habitación. Deja el aire más ligero, como si alguien hubiera abierto una ventana.",
  },
  {
    title: "Cómo escuchas",
    body: "Como si el resto del mundo se hubiera ido un momento. Pocas personas saben hacer eso.",
  },
  {
    title: "Tu forma de estar",
    body: "Intensa y suave a la vez. Ocupas un lugar sin pedirlo, y el lugar se agradece.",
  },
  {
    title: "Lo valiente",
    body: "Aunque no siempre lo notes. Seguir siendo tú, con todo lo que eso implica, ya es un acto de coraje.",
  },
  {
    title: "Lo que no tiene nombre",
    body: "Esto. Nosotros. El espacio entre amiga y algo más. Está bien no saberlo todavía.",
  },
  {
    title: "El resto de tus días",
    body: "Todos los que todavía no llegan. Ojalá sean vastos, extraños y buenos contigo.",
  },
] as const;

const WISHES = [
  "Que nunca te falte una mesa donde reír.",
  "Que el miedo no te convenza de hacerte más pequeña.",
  "Que te enamores de tu propia vida, una y otra vez.",
  "Que el mundo esté, al menos un poco, a la altura de merecerte.",
] as const;

const SEED_STARS = [
  { x: 12, y: 18, s: 2 },
  { x: 23, y: 42, s: 1.5 },
  { x: 31, y: 14, s: 2.5 },
  { x: 44, y: 28, s: 1.5 },
  { x: 52, y: 11, s: 2 },
  { x: 61, y: 36, s: 1.5 },
  { x: 73, y: 22, s: 3 },
  { x: 81, y: 48, s: 1.5 },
  { x: 88, y: 16, s: 2 },
  { x: 17, y: 62, s: 1.5 },
  { x: 38, y: 55, s: 2 },
  { x: 67, y: 58, s: 1.5 },
  { x: 92, y: 33, s: 2 },
  { x: 8, y: 44, s: 1.5 },
  { x: 55, y: 70, s: 2 },
] as const;

type PlacedStar = { id: string; x: number; y: number; s: number };

const STAR_KEY = "para-vale-stars";

export function Letter({ onRestart }: { onRestart: () => void }) {
  return (
    <div className="bg-night text-fg">
      <Hero />
      <Paper />
      <Photos />
      <Notes />
      <Wishes />
      <Constellation />
      <CandleWish />
      <Closing onRestart={onRestart} />
    </div>
  );
}

function Hero() {
  return (
    <header className="hero">
      <img
        src="/images/garden.jpg"
        alt="Un jardín de noche, con una linterna encendida bajo las estrellas"
        className="hero-bg"
      />
      <div className="hero-veil" />
      <div className="relative z-10 max-w-3xl">
        <p className="label text-muted">para Valerie</p>
        <h1 className="display mt-3 text-hero text-fg">Feliz cumpleaños</h1>
        <p className="mt-4 font-display text-lead italic text-fg-dim">
          Un rincón quieto, solo para ti.
        </p>
      </div>
    </header>
  );
}

function Paper() {
  return (
    <article className="sheet" aria-label="Carta">
      <p className="kicker">una carta</p>
      <h2 className="display mt-3 text-title">Vale —</h2>

      <div className="mt-8 space-y-6">
        <p>No sé cómo llamarte.</p>
        <p>
          A veces amiga. A veces algo que todavía no tiene nombre. Hoy no hace falta
          definirlo.
        </p>
        <p>
          Hoy solo quiero que sepas esto: el mundo se siente más habitable porque
          estás en él.
        </p>
        <p>
          Quería darte un lugar quieto. Una carta. Un poco de luz. Las palabras que
          a veces se me traban cuando te miro.
        </p>
        <p>
          Que este año te cuide con ternura. Que te rías hasta que te duela la cara.
          Que te quedes con las personas que te miran de verdad. Y que nunca, ni un
          solo día, dudes de lo extraordinaria que eres.
        </p>
        <p>Gracias por existir.</p>
        <p className="italic">Feliz cumpleaños, Valerie.</p>
      </div>

      <p className="mt-10 font-display text-lg italic text-rose">— alguien que te piensa</p>
    </article>
  );
}

function Photos() {
  return (
    <section className="mx-auto max-w-page px-5 pb-20 md:px-8" aria-label="Imágenes">
      <div className="grid gap-3 md:grid-cols-12 md:gap-4">
        <Reveal as="figure" className="frame md:col-span-5" delay={40}>
          <img
            src="/images/rose.jpg"
            alt="Una rosa de terciopelo, a contraluz"
            className="photo aspect-portrait"
            loading="lazy"
          />
        </Reveal>
        <Reveal as="figure" className="frame md:col-span-7" delay={120}>
          <img
            src="/images/window.jpg"
            alt="Una ventana con lluvia, de noche"
            className="photo aspect-landscape md:aspect-auto md:h-full"
            loading="lazy"
          />
        </Reveal>
      </div>
    </section>
  );
}

function Notes() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="mx-auto max-w-letter px-5 pb-20" aria-label="Cosas que son tuyas">
      <Reveal>
        <p className="label text-center text-muted">cosas que son tuyas</p>
        <h2 className="display mt-3 text-center text-title text-fg">Lo que no siempre digo</h2>
      </Reveal>
      <ul className="mt-8 space-y-3">
        {NOTES.map((note, i) => {
          const isOpen = open === i;
          return (
            <li key={note.title}>
              <div className={cn("note", isOpen && "is-open")}>
                <button
                  type="button"
                  className="note-trigger"
                  aria-expanded={isOpen}
                  onClick={() => setOpen(isOpen ? null : i)}
                >
                  <span className="note-title">{note.title}</span>
                  <ChevronDown
                    className={cn("note-chevron size-5 shrink-0", isOpen && "is-open")}
                    strokeWidth={1.5}
                    aria-hidden="true"
                  />
                </button>
                {isOpen ? <p className="note-body">{note.body}</p> : null}
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

function Wishes() {
  return (
    <section className="mx-auto max-w-letter px-5 pb-20" aria-label="Deseos">
      <Reveal>
        <p className="label text-center text-muted">para este año</p>
        <h2 className="display mt-3 text-center text-title">Cuatro deseos</h2>
      </Reveal>
      <ol className="mt-10 space-y-8">
        {WISHES.map((wish, i) => (
          <Reveal as="li" key={wish} delay={i * 70} className="flex gap-5">
            <span className="font-display text-2xl text-rose" aria-hidden="true">
              {["I", "II", "III", "IV"][i]}
            </span>
            <p className="font-display text-lead text-fg">{wish}</p>
          </Reveal>
        ))}
      </ol>
    </section>
  );
}

function Constellation() {
  const [stars, setStars] = useState<PlacedStar[]>(() =>
    SEED_STARS.map((s, i) => ({ id: `seed-${i}`, x: s.x, y: s.y, s: s.s })),
  );
  const [ready, setReady] = useState(false);
  const extra = stars.filter((s) => s.id.startsWith("me-")).length;

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STAR_KEY);
      if (raw) {
        const saved = JSON.parse(raw) as PlacedStar[];
        if (Array.isArray(saved) && saved.length) {
          const mine = saved.filter((s) => s.id.startsWith("me-"));
          setStars((prev) => [...prev.filter((s) => s.id.startsWith("seed-")), ...mine]);
        }
      }
    } catch {
      /* ignore */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    const mine = stars.filter((s) => s.id.startsWith("me-"));
    try {
      localStorage.setItem(STAR_KEY, JSON.stringify(mine));
    } catch {
      /* ignore */
    }
  }, [stars, ready]);

  const place = (x: number, y: number) => {
    const next: PlacedStar = {
      id: `me-${Date.now()}-${Math.round(x * 10)}`,
      x,
      y,
      s: 1.6 + Math.random() * 1.8,
    };
    setStars((prev) => [...prev, next]);
  };

  const onClick = (e: MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    place(((e.clientX - rect.left) / rect.width) * 100, ((e.clientY - rect.top) / rect.height) * 100);
  };

  const onKeyDown = (e: KeyboardEvent<HTMLButtonElement>) => {
    if (e.key !== "Enter" && e.key !== " ") return;
    e.preventDefault();
    place(20 + Math.random() * 60, 18 + Math.random() * 50);
  };

  return (
    <section className="mx-auto max-w-page px-5 pb-20 md:px-8" aria-label="Cielo">
      <Reveal className="mb-6 flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-end">
        <div>
          <p className="label text-muted">un cielo</p>
          <h2 className="display mt-2 text-title">Deja una estrella para Vale</h2>
        </div>
        <p className="flex items-center gap-2 text-sm text-muted">
          <Star className="size-3.5" strokeWidth={1.6} aria-hidden="true" />
          {extra === 0 ? "Toca el cielo" : extra === 1 ? "1 estrella tuya" : `${extra} estrellas tuyas`}
        </p>
      </Reveal>
      <div className="frame">
        <button
          type="button"
          className="sky"
          onClick={onClick}
          onKeyDown={onKeyDown}
          aria-label="Tocar el cielo para dejar una estrella"
        >
          <img
            src="/images/garden.jpg"
            alt=""
            className="absolute inset-0 h-full w-full object-cover opacity-80"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-night/35" />
          {stars.map((s) => (
            <span
              key={s.id}
              className="sky-star"
              style={{ left: `${s.x}%`, top: `${s.y}%`, width: s.s, height: s.s }}
            />
          ))}
        </button>
      </div>
    </section>
  );
}

function CandleWish() {
  const [blown, setBlown] = useState(false);

  return (
    <section className="mx-auto max-w-letter px-5 pb-20" aria-label="La vela">
      <Reveal className="mb-6 text-center">
        <p className="label text-muted">una vela</p>
        <h2 className="display mt-2 text-title">{blown ? "Ya está" : "Pide un deseo"}</h2>
      </Reveal>
      <figure className="wish frame">
        <div className="wish-stack">
          <img
            src="/images/cake.jpg"
            alt="Un pastel con una sola vela encendida"
            className="wish-photo base"
            loading="lazy"
          />
          <img
            src="/images/cake-out.jpg"
            alt=""
            className={cn("wish-photo", !blown && "is-dim")}
          />
        </div>
      </figure>
      <div className="mt-6 flex flex-col items-center gap-4 text-center">
        {!blown ? (
          <button type="button" className="pill" onClick={() => setBlown(true)}>
            Soplar la vela
            <Flame className="size-4" strokeWidth={1.6} aria-hidden="true" />
          </button>
        ) : (
          <p className="max-w-sm font-display text-lead italic text-fg-dim">
            El universo tomó nota. Que se cumpla, Vale.
          </p>
        )}
      </div>
    </section>
  );
}

function Closing({ onRestart }: { onRestart: () => void }) {
  return (
    <footer className="px-5 pb-16 pt-4 text-center">
      <div className="rule mx-auto max-w-xs">
        <span className="rule-dot" />
      </div>
      <Reveal className="mx-auto mt-10 max-w-md">
        <p className="display text-title text-fg">Vale.</p>
        <p className="mt-4 font-display text-lead italic text-fg-dim">
          El resto es silencio, y cariño.
        </p>
      </Reveal>
      <button type="button" className="pill pill-ghost mt-10" onClick={onRestart}>
        Leer otra vez
      </button>
      <p className="mt-12 label text-muted">para Vale, en su día</p>
    </footer>
  );
}
