import { MailOpen } from "lucide-react";
import { cn } from "@/lib/utils";

export function Gate({ leaving, onOpen }: { leaving: boolean; onOpen: () => void }) {
  return (
    <section className={cn("gate", leaving && "is-leaving")} aria-label="Invitación">
      <img
        src="/images/desk.jpg"
        alt=""
        className="gate-bg"
        fetchPriority="high"
      />
      <div className="gate-veil" />
      <div className="relative z-10 flex w-full max-w-lg flex-col items-center text-center">
        <p className="label text-muted">una carta para</p>
        <h1 className="display mt-3 text-display text-fg">Vale</h1>
        <p className="mt-4 max-w-sm font-display text-lead font-normal italic text-fg-dim">
          Hoy el mundo gira un poco más despacio.
        </p>

        <button
          type="button"
          className="envelope-btn mt-10"
          onClick={onOpen}
          aria-label="Abrir la carta para Vale"
        >
          <img
            src="/images/envelope.jpg"
            alt="Un sobre de lino cerrado con un sello de cera"
            className="envelope-photo"
            fetchPriority="high"
          />
        </button>

        <button type="button" className="pill mt-8" onClick={onOpen}>
          Abrir la carta
          <MailOpen className="size-4" strokeWidth={1.6} aria-hidden="true" />
        </button>
      </div>
    </section>
  );
}
