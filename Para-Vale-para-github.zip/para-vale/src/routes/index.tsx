import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/components/vale/home-page";

export const Route = createFileRoute("/")({ component: HomePage });
